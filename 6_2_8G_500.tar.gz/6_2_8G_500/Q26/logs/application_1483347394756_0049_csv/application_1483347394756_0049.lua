-- DAG definition: it is encoded as an array of stages.
Stages = {{ name="J2S1", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J2S1.txt")}}, pre={}, post={"J3S3","J3S4"}},{ name="J1S0", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J1S0.txt")}}, pre={}, post={"J3S3","J3S4"}},{ name="J3S3", tasks="500", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J3S3.txt")}}, pre={"J1S0","J0S2","J2S1"}, post={"J3S5"}},{ name="J0S2", tasks="2", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J0S2.txt")}}, pre={}, post={"J3S3","J3S4"}},{ name="J3S5", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J3S5.txt")}}, pre={"J3S3","J3S4"}, post={"J3S6"}},{ name="J3S4", tasks="500", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J3S4.txt")}}, pre={"J1S0","J0S2","J2S1"}, post={"J3S5"}},{ name="J3S6", tasks="200", distr={type="replay", params={samples=solver.fileToArray("/home/work/TPCDS500-D_processed_logs/6_2_8G_500/Q26/logs/application_1483347394756_0049_csv/J3S6.txt")}}, pre={"J3S5"}, post={}}};

-- Number of computation nodes in the system
Nodes = 12;

-- Number of users accessing the system
Users = 1;

-- Distribution of the think time for the users
UThinkTimeDistr = {type = "exp", params = {rate = 0.001}};

-- Total number of jobs to simulate
maxJobs = 1000;

-- Coefficient for the Confidence Intervals
confIntCoeff = 1.96;
